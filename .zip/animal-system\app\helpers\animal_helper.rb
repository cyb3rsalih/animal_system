module AnimalHelper
end
